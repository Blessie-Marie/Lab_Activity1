package com.soriano.myustapp;

import androidx.appcompat.app.AppCompatActivity;
import android.app.IntentService;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class Portals extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_portals);
    }

    public void displayUSTWeb(View v){
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse("http://www.ust.edu.ph"));
        startActivity(i);

    }

    public void displayMyUste(View v){
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse("http://www.myuste.edu.ph"));
        startActivity(i);

    }

    public void displayBlackboard(View v){
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse("http://www.ust.blackboard.com"));
        startActivity(i);

    }

//    public Portals(){
//        super ("Portals");
//    }

  //  @Override


//    public void displayHello(View v){
//        for (int i=0; i<10; i++){
//            Log.d("Portals", "Hello" + (i+1));
//        }
//    }
}
